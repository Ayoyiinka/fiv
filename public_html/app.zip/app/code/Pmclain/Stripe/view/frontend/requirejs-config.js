var config = {
  map: {
    '*': {
      stripejs: 'https://js.stripe.com/v3/'
    }
  }
};