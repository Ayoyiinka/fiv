<?php

namespace DR\Gallery\Block\Widget;

use DR\Gallery\Block\Gallery as GalleryBlock;
use Magento\Widget\Block\BlockInterface;

class Gallery extends GalleryBlock implements BlockInterface
{
}