var config = {
    map: {
        '*': {
            snapGallery: 'DR_Gallery/js/snapGallery'
        }
    }
};
