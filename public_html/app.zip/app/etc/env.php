<?php
return array (
  'backend' => 
  array (
    'frontName' => 'backend',
  ),
  'crypt' => 
  array (
    'key' => 'dc84efd1119c3faf7d42415fb246ebd9',
  ),
  'session' => 
  array (
    'save' => 'files',
  ),
  'db' => 
  array (
    'table_prefix' => 'cf_',
    'connection' => 
    array (
      'default' => 
      array (
        'host' => 'localhost',
        'dbname' => 'cfdb',
        'username' => 'remote',
        'password' => 'GhQ@aFGhAJNgOA8AJk',
        'active' => '1',
      ),
    ),
  ),
  'resource' => 
  array (
    'default_setup' => 
    array (
      'connection' => 'default',
    ),
  ),
  'x-frame-options' => 'SAMEORIGIN',
  'MAGE_MODE' => 'developer',
  'cache_types' => 
  array (
    'config' => 0,
    'layout' => 0,
    'block_html' => 0,
    'collections' => 0,
    'reflection' => 0,
    'db_ddl' => 0,
    'eav' => 0,
    'customer_notification' => 0,
    'full_page' => 0,
    'config_integration' => 0,
    'config_integration_api' => 0,
    'translate' => 0,
    'config_webservice' => 0,
    'compiled_config' => 0,
  ),
  'install' => 
  array (
    'date' => 'Wed, 16 Aug 2017 11:15:59 +0000',
  ),
);
